package mk.finki.ukim.mk.emtlab;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EmtLabApplicationTests {

	@Test
	void contextLoads() {
	}

}
