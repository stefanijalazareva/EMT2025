package mk.finki.ukim.mk.emtlab.service.application.impl;

import mk.finki.ukim.mk.emtlab.dto.CreateAuthorDto;
import mk.finki.ukim.mk.emtlab.dto.DisplayAuthorDto;
import mk.finki.ukim.mk.emtlab.service.application.AuthorApplicationService;
import mk.finki.ukim.mk.emtlab.service.domain.AuthorService;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class AuthorApplicationServiceImpl implements AuthorApplicationService {
    private final AuthorService authorService;

    public AuthorApplicationServiceImpl(AuthorService authorService) {
        this.authorService = authorService;
    }

    @Override
    public List<DisplayAuthorDto> findAll() {
        return authorService.findAll().stream()
                .map(DisplayAuthorDto::fromEntity).toList();
    }

    @Override
    public Optional<DisplayAuthorDto> findById(Long id) {
        return authorService.findById(id).map(DisplayAuthorDto::fromEntity);
    }

    @Override
    public Optional<DisplayAuthorDto> create(CreateAuthorDto authorRequestDTO) {
        return authorService.create(
                authorRequestDTO.name(),
                authorRequestDTO.surname(),
                authorRequestDTO.countryId()
        ).map(DisplayAuthorDto::fromEntity);
    }

    @Override
    public Optional<DisplayAuthorDto> update(Long id, CreateAuthorDto authorRequestDTO) {
        return authorService.update(
                id,
                authorRequestDTO.name(),
                authorRequestDTO.surname(),
                authorRequestDTO.countryId()
        ).map(DisplayAuthorDto::fromEntity);
    }

    @Override
    public boolean deleteById(Long id) {
        return authorService.deleteById(id);
    }
}
