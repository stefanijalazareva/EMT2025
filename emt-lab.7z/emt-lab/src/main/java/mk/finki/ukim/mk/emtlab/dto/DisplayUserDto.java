package mk.finki.ukim.mk.emtlab.dto;

import mk.finki.ukim.mk.emtlab.model.domain.User;
import mk.finki.ukim.mk.emtlab.model.enums.Role;

public record DisplayUserDto(String username, String name, String surname, Role role) {

    public static DisplayUserDto fromEntity(User user) {
        return new DisplayUserDto(
                user.getUsername(),
                user.getName(),
                user.getSurname(),
                user.getRole()
        );
    }

    public User toEntity() {
        return new User(username, name, surname, role.name());
    }
}