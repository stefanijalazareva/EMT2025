package mk.finki.ukim.mk.emtlab.service.application.impl;

import mk.finki.ukim.mk.emtlab.dto.CreateBookDto;
import mk.finki.ukim.mk.emtlab.dto.DisplayBookDto;
import mk.finki.ukim.mk.emtlab.dto.DisplayBookInventoryDto;
import mk.finki.ukim.mk.emtlab.model.domain.BookInventory;
import mk.finki.ukim.mk.emtlab.service.application.BookApplicationService;
import mk.finki.ukim.mk.emtlab.service.domain.BookInventoryService;
import mk.finki.ukim.mk.emtlab.service.domain.BookService;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class BookApplicationServiceImpl implements BookApplicationService {
    private final BookService bookService;
    private final BookInventoryService bookInventoryService;

    public BookApplicationServiceImpl(BookService bookService, BookInventoryService bookInventoryService) {
        this.bookService = bookService;
        this.bookInventoryService = bookInventoryService;
    }

    @Override
    public List<DisplayBookDto> findAll() {
        return bookService.findAll().stream().map(DisplayBookDto::fromEntity).toList();
    }

    @Override
    public Optional<DisplayBookDto> findById(Long id) {
        return bookService.findById(id).map(DisplayBookDto::fromEntity);
    }

    @Override
    public Optional<DisplayBookDto> create(CreateBookDto bookRequestDTO) {
        return bookService.create(
                bookRequestDTO.name(),
                bookRequestDTO.category(),
                bookRequestDTO.authorId(),
                bookRequestDTO.availableCopies()
        ).map(DisplayBookDto::fromEntity);
    }

    @Override
    public Optional<DisplayBookDto> update(Long id, CreateBookDto bookRequestDTO) {
        return bookService.update(
                id,
                bookRequestDTO.name(),
                bookRequestDTO.category(),
                bookRequestDTO.authorId(),
                bookRequestDTO.availableCopies()
        ).map(DisplayBookDto::fromEntity);
    }

    @Override
    public boolean deleteById(Long id) {
        return bookService.deleteById(id);
    }

    @Override
    public Optional<DisplayBookInventoryDto> borrowBook(Long id) {
        return bookInventoryService.borrowBook(id).map(DisplayBookInventoryDto::fromEntity);
    }

    @Override
    public Optional<DisplayBookInventoryDto> returnBook(Long id) {
        return bookInventoryService.returnBook(id).map(DisplayBookInventoryDto::fromEntity);
    }

    @Override
    public List<DisplayBookDto> findByNameOrAuthor(String query) {
        return bookService.findByNameOrAuthor(query).stream().map(DisplayBookDto::fromEntity).toList();
    }
}
