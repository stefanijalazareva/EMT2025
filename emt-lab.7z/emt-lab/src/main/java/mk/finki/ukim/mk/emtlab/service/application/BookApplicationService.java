package mk.finki.ukim.mk.emtlab.service.application;

import mk.finki.ukim.mk.emtlab.dto.CreateBookDto;
import mk.finki.ukim.mk.emtlab.dto.DisplayBookDto;
import mk.finki.ukim.mk.emtlab.dto.DisplayBookInventoryDto;

import java.util.List;
import java.util.Optional;

public interface BookApplicationService {
    List<DisplayBookDto> findAll();

    Optional<DisplayBookDto> findById(Long id);

    Optional<DisplayBookDto> create(CreateBookDto bookRequestDTO);

    Optional<DisplayBookDto> update(Long id, CreateBookDto bookRequestDTO);

    boolean deleteById(Long id);

    Optional<DisplayBookInventoryDto> borrowBook(Long id);

    Optional<DisplayBookInventoryDto> returnBook(Long id);

    List<DisplayBookDto> findByNameOrAuthor(String query);
}
