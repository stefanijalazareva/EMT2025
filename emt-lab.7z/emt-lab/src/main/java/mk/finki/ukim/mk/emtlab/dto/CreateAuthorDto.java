package mk.finki.ukim.mk.emtlab.dto;

import mk.finki.ukim.mk.emtlab.model.domain.Author;
import mk.finki.ukim.mk.emtlab.model.domain.Country;

public record CreateAuthorDto(String name, String surname, Long countryId) {
    public Author toEntity(Country country) {
        return new Author(name, surname, country);
    }
}
