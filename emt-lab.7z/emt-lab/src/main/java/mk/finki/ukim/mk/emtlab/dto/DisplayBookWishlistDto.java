package mk.finki.ukim.mk.emtlab.dto;

import mk.finki.ukim.mk.emtlab.model.domain.Book;

public record DisplayBookWishlistDto(Long id, String name) {
    public static DisplayBookWishlistDto fromEntity(Book book) {
        return new DisplayBookWishlistDto(book.getId(), book.getName());
    }
}
