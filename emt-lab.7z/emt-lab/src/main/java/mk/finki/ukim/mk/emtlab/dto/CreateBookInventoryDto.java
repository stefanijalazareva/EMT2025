package mk.finki.ukim.mk.emtlab.dto;

import mk.finki.ukim.mk.emtlab.model.domain.Author;
import mk.finki.ukim.mk.emtlab.model.domain.Book;
import mk.finki.ukim.mk.emtlab.model.enums.Category;

public record CreateBookInventoryDto(String name, String category, Long authorId, int availableCopies) {
    public Book toEntity(Category category, Author author) {
        return new Book(name, category, author);
    }
}
