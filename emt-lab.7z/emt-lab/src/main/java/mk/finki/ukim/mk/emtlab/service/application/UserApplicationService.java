package mk.finki.ukim.mk.emtlab.service.application;

import mk.finki.ukim.mk.emtlab.dto.*;

import java.util.Optional;

public interface UserApplicationService {
    Optional<DisplayUserDto> register(CreateUserDto createUserDto);

    Optional<DisplayUserDto> login(LoginUserDto loginUserDto);

    Optional<DisplayUserDto> findByUsername(String username);

    Optional<DisplayUserWishListDto> findUserWishlist(String username);

    Optional<DisplayUserWishListDto> addBookToWishlist(CreateUserWishListDto userWishlistRequestDTO);

    Optional<DisplayUserWishListDto> removeBookFromWishlist(CreateUserWishListDto userWishlistRequestDTO);

    Optional<DisplayUserWishListDto> borrowBookFromWishlist(CreateUserWishListDto userWishlistRequestDTO);

    Optional<DisplayUserWishListDto> borrowAllBooksFromWishlist(String username);
}
