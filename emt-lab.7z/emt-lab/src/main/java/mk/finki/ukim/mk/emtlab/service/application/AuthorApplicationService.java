package mk.finki.ukim.mk.emtlab.service.application;


import mk.finki.ukim.mk.emtlab.dto.CreateAuthorDto;
import mk.finki.ukim.mk.emtlab.dto.DisplayAuthorDto;

import java.util.List;
import java.util.Optional;

public interface AuthorApplicationService {
    List<DisplayAuthorDto> findAll();
    Optional<DisplayAuthorDto> findById(Long id);
    Optional<DisplayAuthorDto> create(CreateAuthorDto authorRequestDTO);
    Optional<DisplayAuthorDto> update(Long id, CreateAuthorDto authorRequestDTO);
    boolean deleteById(Long id);
}
