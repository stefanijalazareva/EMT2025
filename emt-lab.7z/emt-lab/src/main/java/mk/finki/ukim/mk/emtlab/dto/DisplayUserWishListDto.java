package mk.finki.ukim.mk.emtlab.dto;

import mk.finki.ukim.mk.emtlab.model.domain.User;

import java.util.List;

public record DisplayUserWishListDto(String username, List<DisplayBookWishlistDto> wishlist) {
    public static DisplayUserWishListDto fromEntity(User user) {

        return new DisplayUserWishListDto(
                user.getUsername(),
                user.getWishlist().stream().map(DisplayBookWishlistDto::fromEntity).toList()
        );
    }
}
