package mk.finki.ukim.mk.emtlab.dto;

import mk.finki.ukim.mk.emtlab.model.domain.Country;

public record CreateCountryDto(String name, String continent) {
    public Country toEntity() {
        return new Country(name, continent);
    }
}
