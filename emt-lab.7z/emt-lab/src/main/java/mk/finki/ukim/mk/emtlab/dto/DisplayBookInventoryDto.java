package mk.finki.ukim.mk.emtlab.dto;

import mk.finki.ukim.mk.emtlab.model.domain.BookInventory;

public record DisplayBookInventoryDto(Long id, Long bookId, String bookName, int availableCopies) {
    public static DisplayBookInventoryDto fromEntity(BookInventory bookInventory) {

        return new DisplayBookInventoryDto(
                bookInventory.getId(),
                bookInventory.getBook().getId(),
                bookInventory.getBook().getName(),
                bookInventory.getAvailableCopies()
        );
    }
}
