package mk.finki.ukim.mk.emtlab.model.exceptions;

public class NotAvailableCopiesException extends RuntimeException {
    public NotAvailableCopiesException(Long id) {
        super(String.format("There are no available copies of book with id %d", id));
    }
}
