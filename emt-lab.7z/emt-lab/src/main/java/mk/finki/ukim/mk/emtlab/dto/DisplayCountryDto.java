package mk.finki.ukim.mk.emtlab.dto;

import mk.finki.ukim.mk.emtlab.model.domain.Country;

public record DisplayCountryDto(Long id, String name, String continent) {
    public static DisplayCountryDto fromEntity(Country country) {
        return new DisplayCountryDto(
                country.getId(),
                country.getName(),
                country.getContinent()
        );
    }
}
