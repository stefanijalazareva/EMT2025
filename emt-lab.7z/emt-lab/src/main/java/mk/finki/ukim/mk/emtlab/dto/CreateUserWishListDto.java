package mk.finki.ukim.mk.emtlab.dto;

public record CreateUserWishListDto(String username, Long bookId) {
}
