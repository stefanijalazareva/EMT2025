package mk.finki.ukim.mk.emtlab.dto;

import mk.finki.ukim.mk.emtlab.model.domain.Author;

public record DisplayAuthorDto(Long id, String name, String surname, Long countryId) {
    public static DisplayAuthorDto fromEntity(Author author) {
        return new DisplayAuthorDto(
                author.getId(),
                author.getName(),
                author.getSurname(),
                author.getCountry().getId()
        );
    }
}
