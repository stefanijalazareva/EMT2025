package mk.finki.ukim.mk.emtlab.service.application.impl;

import mk.finki.ukim.mk.emtlab.dto.CreateCountryDto;
import mk.finki.ukim.mk.emtlab.dto.DisplayCountryDto;
import mk.finki.ukim.mk.emtlab.service.application.CountryApplicationService;
import mk.finki.ukim.mk.emtlab.service.domain.CountryService;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class CountryApplicationServiceImpl implements CountryApplicationService {
    private final CountryService countryService;

    public CountryApplicationServiceImpl(CountryService countryService) {
        this.countryService = countryService;
    }

    @Override
    public List<DisplayCountryDto> findAll() {
        return countryService.findAll().stream().map(DisplayCountryDto::fromEntity).toList();
    }

    @Override
    public Optional<DisplayCountryDto> findById(Long id) {
        return countryService.findById(id).map(DisplayCountryDto::fromEntity);
    }

    @Override
    public Optional<DisplayCountryDto> create(CreateCountryDto countryRequestDTO) {
        return countryService.create(
                countryRequestDTO.name(),
                countryRequestDTO.continent()
        ).map(DisplayCountryDto::fromEntity);
    }

    @Override
    public Optional<DisplayCountryDto> update(Long id, CreateCountryDto countryRequestDTO) {
        return countryService.update(
                id,
                countryRequestDTO.name(),
                countryRequestDTO.continent()
        ).map(DisplayCountryDto::fromEntity);
    }

    @Override
    public boolean deleteById(Long id) {
        return countryService.deleteById(id);
    }
}
