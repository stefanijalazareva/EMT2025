package mk.finki.ukim.mk.emtlab.model.exceptions;

public class InvalidUserCredentialsException extends RuntimeException {
    public InvalidUserCredentialsException() {
        super("Invalid User Credentials!");
    }
}
