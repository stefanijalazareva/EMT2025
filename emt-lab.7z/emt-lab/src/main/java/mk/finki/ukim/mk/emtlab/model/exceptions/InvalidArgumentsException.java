package mk.finki.ukim.mk.emtlab.model.exceptions;

public class InvalidArgumentsException extends RuntimeException {
    public InvalidArgumentsException() {
        super("Invalid arguments!");
    }
}
