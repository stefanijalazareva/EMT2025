package mk.finki.ukim.mk.emtlab.dto;

public record LoginUserDto(String username, String password) {
}
