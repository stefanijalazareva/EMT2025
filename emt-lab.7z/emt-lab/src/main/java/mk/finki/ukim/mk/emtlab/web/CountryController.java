package mk.finki.ukim.mk.emtlab.web;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import mk.finki.ukim.mk.emtlab.dto.CreateCountryDto;
import mk.finki.ukim.mk.emtlab.dto.DisplayCountryDto;
import mk.finki.ukim.mk.emtlab.model.exceptions.CountryNotFoundException;
import mk.finki.ukim.mk.emtlab.service.application.CountryApplicationService;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/countries")
@Tag(name = "Country API", description = "Endpoints for managing countries")
public class CountryController {

    private final CountryApplicationService countryService;

    public CountryController(CountryApplicationService countryService) {
        this.countryService = countryService;
    }

    @Operation(
            summary = "Get all countries", description = "Retrieves a list of all countries."
    )
    @GetMapping
    public List<DisplayCountryDto> listAll() {

        return countryService.findAll();
    }

    @Operation(summary = "Get country by ID", description = "Finds a country by it's ID.")
    @GetMapping("/{id}")
    public ResponseEntity<DisplayCountryDto> findById(@PathVariable Long id) {
        try {
            return countryService.findById(id)
                    .map(ResponseEntity::ok)
                    .orElseGet(() -> ResponseEntity.notFound().build());
        } catch (CountryNotFoundException exception) {
            return ResponseEntity.badRequest().build();
        }
    }

    @Operation(summary = "Create new country", description = "Creates a new country.")
    @PostMapping("/add")
    public ResponseEntity<DisplayCountryDto> create(@RequestBody CreateCountryDto countryRequestDTO) {

        return countryService.create(countryRequestDTO)
                .map(ResponseEntity::ok)
                .orElseGet(() -> ResponseEntity.badRequest().build());
    }

    @Operation(summary = "Update existing country", description = "Updates a country by it's ID.")
    @PutMapping("/edit/{id}")
    public ResponseEntity<DisplayCountryDto> update(@PathVariable Long id,
                                                     @RequestBody CreateCountryDto countryRequestDTO) {
        try {
            return countryService.update(id, countryRequestDTO)
                    .map(ResponseEntity::ok)
                    .orElseGet(() -> ResponseEntity.badRequest().build());
        } catch (CountryNotFoundException exception) {
            return ResponseEntity.badRequest().build();
        }
    }

    @Operation(summary = "Delete country", description = "Deletes a country by it's ID.")
    @DeleteMapping("/delete/{id}")
    public ResponseEntity<Boolean> delete(@PathVariable Long id) {
        try {
            return ResponseEntity.ok(countryService.deleteById(id));
        } catch (CountryNotFoundException e) {
            return ResponseEntity.badRequest().build();
        }
    }
}