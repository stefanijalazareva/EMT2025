package mk.finki.ukim.mk.emtlab.service.application.impl;

import mk.finki.ukim.mk.emtlab.dto.*;
import mk.finki.ukim.mk.emtlab.service.application.UserApplicationService;
import mk.finki.ukim.mk.emtlab.service.domain.UserService;
import org.springframework.stereotype.Service;

import java.util.Optional;

@Service
public class UserApplicationServiceImpl implements UserApplicationService {
    private final UserService userService;

    public UserApplicationServiceImpl(UserService userService) {
        this.userService = userService;
    }

    @Override
    public Optional<DisplayUserDto> register(CreateUserDto createUserDto) {
        return userService.register(
                createUserDto.username(),
                createUserDto.password(),
                createUserDto.repeatPassword(),
                createUserDto.name(),
                createUserDto.surname(),
                createUserDto.role()
        ).map(DisplayUserDto::fromEntity);
    }

    @Override
    public Optional<DisplayUserDto> login(LoginUserDto loginUserDto) {
        return userService.login(
                loginUserDto.username(),
                loginUserDto.password()
        ).map(DisplayUserDto::fromEntity);
    }

    @Override
    public Optional<DisplayUserDto> findByUsername(String username) {
        return userService.findByUsername(username)
                .map(DisplayUserDto::fromEntity);
    }

    @Override
    public Optional<DisplayUserWishListDto> findUserWishlist(String username) {
        return userService.findByUsername(username)
                .map(DisplayUserWishListDto::fromEntity);
    }

    @Override
    public Optional<DisplayUserWishListDto> addBookToWishlist(CreateUserWishListDto userWishlistRequestDTO) {
        return userService
                .addBookToWishlist(userWishlistRequestDTO.username(), userWishlistRequestDTO.bookId())
                .map(DisplayUserWishListDto::fromEntity);
    }

    @Override
    public Optional<DisplayUserWishListDto> removeBookFromWishlist(CreateUserWishListDto userWishlistRequestDTO) {
        return userService.removeBookFromWishlist(userWishlistRequestDTO.username(), userWishlistRequestDTO.bookId())
                .map(DisplayUserWishListDto::fromEntity);
    }

    @Override
    public Optional<DisplayUserWishListDto> borrowBookFromWishlist(CreateUserWishListDto userWishlistRequestDTO) {
        return userService.borrowBookFromWishlist(userWishlistRequestDTO.username(), userWishlistRequestDTO.bookId())
                .map(DisplayUserWishListDto::fromEntity);
    }

    @Override
    public Optional<DisplayUserWishListDto> borrowAllBooksFromWishlist(String username) {
        return userService.borrowAllBooksFromWishlist(username)
                .map(DisplayUserWishListDto::fromEntity);
    }
}
