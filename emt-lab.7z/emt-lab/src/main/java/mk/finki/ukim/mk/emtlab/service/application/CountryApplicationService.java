package mk.finki.ukim.mk.emtlab.service.application;

import mk.finki.ukim.mk.emtlab.dto.CreateCountryDto;
import mk.finki.ukim.mk.emtlab.dto.DisplayCountryDto;

import java.util.List;
import java.util.Optional;

public interface CountryApplicationService {
    List<DisplayCountryDto> findAll();

    Optional<DisplayCountryDto> findById(Long id);

    Optional<DisplayCountryDto> create(CreateCountryDto countryRequestDTO);

    Optional<DisplayCountryDto> update(Long id, CreateCountryDto countryRequestDTO);

    boolean deleteById(Long id);
}
