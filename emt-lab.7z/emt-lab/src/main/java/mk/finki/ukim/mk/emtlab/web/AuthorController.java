package mk.finki.ukim.mk.emtlab.web;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import mk.finki.ukim.mk.emtlab.dto.CreateAuthorDto;
import mk.finki.ukim.mk.emtlab.dto.DisplayAuthorDto;
import mk.finki.ukim.mk.emtlab.model.exceptions.AuthorNotFoundException;
import mk.finki.ukim.mk.emtlab.model.exceptions.CountryNotFoundException;
import mk.finki.ukim.mk.emtlab.service.application.AuthorApplicationService;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/authors")
@Tag(name = "Author API", description = "Endpoints for managing authors")
public class AuthorController {
    private final AuthorApplicationService authorService;

    public AuthorController(AuthorApplicationService authorService) {
        this.authorService = authorService;
    }

    @Operation(
            summary = "Get all authors", description = "Retrieves a list of all authors."
    )
    @GetMapping
    public List<DisplayAuthorDto> listAll() {

        return authorService.findAll();
    }

    @Operation(summary = "Get author by ID", description = "Finds an author by their ID.")
    @GetMapping("/{id}")
    public ResponseEntity<DisplayAuthorDto> findById(@PathVariable Long id) {
        try {
            return authorService.findById(id)
                    .map(ResponseEntity::ok)
                    .orElseGet(() -> ResponseEntity.notFound().build());
        } catch (AuthorNotFoundException exception) {
            return ResponseEntity.badRequest().build();
        }

    }

    @Operation(summary = "Create new author", description = "Creates a new author.")
    @PostMapping("/add")
    public ResponseEntity<DisplayAuthorDto> create(@RequestBody CreateAuthorDto authorRequestDTO) {

        return authorService.create(authorRequestDTO)
                .map(ResponseEntity::ok)
                .orElseGet(() -> ResponseEntity.badRequest().build());
    }

    @Operation(summary = "Update existing author", description = "Updates an author by their ID.")
    @PutMapping("/edit/{id}")
    public ResponseEntity<DisplayAuthorDto> update(@PathVariable Long id,
                                                    @RequestBody CreateAuthorDto authorRequestDTO) {
        try {
            return authorService.update(id, authorRequestDTO)
                    .map(ResponseEntity::ok)
                    .orElseGet(() -> ResponseEntity.badRequest().build());
        } catch (AuthorNotFoundException | CountryNotFoundException exception) {
            return ResponseEntity.badRequest().build();
        }

    }

    @Operation(summary = "Delete author", description = "Deletes an author by their ID.")
    @DeleteMapping("/delete/{id}")
    public ResponseEntity<Boolean> delete(@PathVariable Long id) {
        try {
            return  ResponseEntity.ok(authorService.deleteById(id));
        } catch (AuthorNotFoundException exception) {
            return ResponseEntity.badRequest().build();
        }

    }

}
