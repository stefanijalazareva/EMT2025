package mk.finki.ukim.mk.emtlab.dto;

import mk.finki.ukim.mk.emtlab.model.domain.Book;

public record DisplayBookDto(Long id, String name, String category, Long authorId, Integer availableCopies) {
    public static DisplayBookDto fromEntity(Book book) {
        return new DisplayBookDto(
                book.getId(),
                book.getName(),
                book.getCategory().name(),
                book.getAuthor().getId(),
                book.getInventory().getAvailableCopies()
        );
    }
}
